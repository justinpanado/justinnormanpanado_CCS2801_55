package com.example.facebook

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
